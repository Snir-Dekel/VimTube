let rate_indicator
let video
let Qs = []
let timeout;
let showTimestamps = true
let EditWithNumbers = false
let bar
let counter
let updateHeatmap = true
let alwaysShowHeatmap = true
let secondsSplit
let heatMapChart
let startOffset
let isStartOffset = false
let offsetsArr = []
let continuousStamp
let startPlayDate = 0
let totalPlayTime = 0
let canvasDiv
let extensionDisabled = false
let autoSaveOn = false
let windowURLIndex
let tinyMDE
let isHideMDE = false
let SVGsDict = {
    trashSvg: '<svg viewBox="0 0 34 44" fill="none" xmlns="http://www.w3.org/2000/svg" width="90px" height="70px"><g style="cursor: pointer"> <path d="M20.5001 6H3.5 M6.5 6C6.55588 6 6.58382 6 6.60915 5.99936C7.43259 5.97849 8.15902 5.45491 8.43922 4.68032C8.44784 4.65649 8.45667 4.62999 8.47434 4.57697L8.57143 4.28571C8.65431 4.03708 8.69575 3.91276 8.75071 3.8072C8.97001 3.38607 9.37574 3.09364 9.84461 3.01877C9.96213 3 10.0932 3 10.3553 3H13.6447C13.9068 3 14.0379 3 14.1554 3.01877C14.6243 3.09364 15.03 3.38607 15.2493 3.8072C15.3043 3.91276 15.3457 4.03708 15.4286 4.28571L15.5257 4.57697C15.5433 4.62992 15.5522 4.65651 15.5608 4.68032C15.841 5.45491 16.5674 5.97849 17.3909 5.99936C17.4162 6 17.4441 6 17.5 6" stroke="#1C274C" stroke-width="1.5" stroke-linecap="round" style="fill: hsl(0 70% 50% / 1);cursor: pointer;transform-origin: right bottom;transition: transform 200ms cubic-bezier(0.4, 0.0, 0.2, 1);transform: translate(0px, 1px);stroke: white;" id="move_path"></path> <path d="M18.8332 8.5L18.3732 15.3991C18.1962 18.054 18.1077 19.3815 17.2427 20.1907C16.3777 21 15.0473 21 12.3865 21H11.6132C8.95235 21 7.62195 21 6.75694 20.1907C5.89194 19.3815 5.80344 18.054 5.62644 15.3991L5.1665 8.5" stroke="#1C274C" stroke-width="1.5" stroke-linecap="round" style="    fill: hsl(0 70% 50% / 1);    cursor: pointer;    stroke: white;"></path> <path d="M9.5 11L10 16" stroke="#1C274C" stroke-width="1.5" stroke-linecap="round" style="    stroke: white;"></path> <path d="M14.5 11L14 16" stroke="#1C274C" stroke-width="1.5" stroke-linecap="round" style="    stroke: white;"></path>  </g></svg>',
    vimTubeSvg: '<svg width="0" height="0" version="1.1" xmlns="http://www.w3.org/2000/svg" style="margin-top: -7rem;">            <defs>          <linearGradient id="blueGradient">        <stop offset="0%" stop-color="rgba(50,94,244,1)" style="    stop-color: hsl(230 90% 58% / 1);"></stop>        <stop offset="25%" stop-color="rgba(50,129,244,1)" style="    /* stop-color: hsl(216 90% 52% / 1); */"></stop>        <stop offset="50%" stop-color=" rgba(50,139,244,1)" style="    stop-color: hsl(210 90% 65% / 1);"></stop>        <stop offset="75%" stop-color=" rgba(50,129,244,1)"></stop>        <stop offset="100%" stop-color="rgb(50, 94, 244)" style="    stop-color: hsl(230 90% 58% / 1);"></stop>        </linearGradient><linearGradient id="goldGradient">       <stop style="stop-opacity:1;stop-color: hsl(37 100% 47% / 1);" offset="0" id="stop22"></stop>                  <stop style="stop-opacity:1;stop-color: #ffda4e;" offset="0.3" id="stop28"></stop>      <stop style="stop-opacity:1;stop-color: hsl(37 100% 47% / 1);" offset="1" id="stop30"></stop>     </linearGradient>      </defs>                </svg>',
    vimTubeGroupTag: '<g id="svgGroup" stroke-linecap="round" fill-rule="evenodd" font-size="9pt" stroke-width="0.15mm" style="stroke: currentColor;stroke-width: 0.15mm;transform: translate(37%, 0%);"><path d="M 5.15 0 L 7.575 0 L 5.15 18.375 L 2 18.375 L 0 0 L 2.4 0 L 2.925 5.525 Q 3.225 8.65 3.675 15.15 A 616.104 616.104 0 0 1 3.833 13.348 Q 4.1 10.344 4.55 5.525 L 5.15 0 Z" id="0" vector-effect="non-scaling-stroke"></path><path d="M 10.5 4.6 L 10.5 18.375 L 8.375 18.375 L 8.375 4.6 L 10.5 4.6 Z M 10.5 0 L 10.5 1.825 L 8.375 1.825 L 8.375 0 L 10.5 0 Z" id="1" vector-effect="non-scaling-stroke"></path><path d="M 22.4 8.3 L 22.4 18.375 L 20.25 18.375 L 20.25 8.35 A 2.577 2.577 0 0 0 20.209 7.868 Q 20.048 7.025 19.25 7.025 A 1.153 1.153 0 0 0 18.813 7.101 Q 18.313 7.305 18.257 8.052 A 2.641 2.641 0 0 0 18.25 8.25 L 18.25 18.375 L 16.1 18.375 L 16.1 8.35 A 2.61 2.61 0 0 0 16.058 7.859 Q 15.904 7.059 15.185 7.004 A 1.435 1.435 0 0 0 15.075 7 Q 14.575 7 14.3 7.413 A 1.645 1.645 0 0 0 14.025 8.317 A 1.986 1.986 0 0 0 14.025 8.35 L 14.025 18.375 L 11.9 18.375 L 11.9 4.6 L 14.025 4.6 L 14.025 6.1 A 3.296 3.296 0 0 1 14.509 5.47 A 4.57 4.57 0 0 1 15.063 4.987 Q 15.577 4.604 16.057 4.507 A 1.611 1.611 0 0 1 16.375 4.475 A 1.511 1.511 0 0 1 17.25 4.727 Q 17.771 5.083 18.01 5.945 A 4.022 4.022 0 0 1 18.025 6 A 2.067 2.067 0 0 1 18.637 5.182 A 2.844 2.844 0 0 1 19.05 4.9 Q 19.8 4.475 20.55 4.475 A 1.5 1.5 0 0 1 21.438 4.738 Q 21.933 5.087 22.175 5.9 A 4.499 4.499 0 0 1 22.284 6.413 Q 22.4 7.15 22.4 8.3 Z" id="2" vector-effect="non-scaling-stroke"></path></g><g>                                <path d="M64.4755 3.68758H61.6768V18.5629H58.9181V3.68758H56.1194V1.42041H64.4755V3.68758Z"></path>        <path d="M71.2768 18.5634H69.0708L68.8262 17.03H68.7651C68.1654 18.1871 67.267 18.7656 66.0675 18.7656C65.2373 18.7656 64.6235 18.4928 64.2284 17.9496C63.8333 17.4039 63.6357 16.5526 63.6357 15.3955V6.03751H66.4556V15.2308C66.4556 15.7906 66.5167 16.188 66.639 16.4256C66.7613 16.6631 66.9659 16.783 67.2529 16.783C67.4974 16.783 67.7326 16.7078 67.9584 16.5573C68.1842 16.4067 68.3488 16.2162 68.4593 15.9858V6.03516H71.2768V18.5634Z"></path>        <path d="M80.609 8.0387C80.4373 7.24849 80.1621 6.67699 79.7812 6.32186C79.4002 5.96674 78.8757 5.79035 78.2078 5.79035C77.6904 5.79035 77.2059 5.93616 76.7567 6.23014C76.3075 6.52412 75.9594 6.90747 75.7148 7.38489H75.6937V0.785645H72.9773V18.5608H75.3056L75.5925 17.3755H75.6537C75.8724 17.7988 76.1993 18.1304 76.6344 18.3774C77.0695 18.622 77.554 18.7443 78.0855 18.7443C79.038 18.7443 79.7412 18.3045 80.1904 17.4272C80.6396 16.5476 80.8653 15.1765 80.8653 13.3092V11.3266C80.8653 9.92722 80.7783 8.82892 80.609 8.0387ZM78.0243 13.1492C78.0243 14.0617 77.9867 14.7767 77.9114 15.2941C77.8362 15.8115 77.7115 16.1808 77.5328 16.3971C77.3564 16.6158 77.1165 16.724 76.8178 16.724C76.585 16.724 76.371 16.6699 76.1734 16.5594C75.9759 16.4512 75.816 16.2866 75.6937 16.0702V8.96062C75.7877 8.6196 75.9524 8.34209 76.1852 8.12337C76.4157 7.90465 76.6697 7.79646 76.9401 7.79646C77.2271 7.79646 77.4481 7.90935 77.6034 8.13278C77.7609 8.35855 77.8691 8.73485 77.9303 9.26636C77.9914 9.79787 78.022 10.5528 78.022 11.5335V13.1492H78.0243Z"></path>        <path d="M84.8657 13.8712C84.8657 14.6755 84.8892 15.2776 84.9363 15.6798C84.9833 16.0819 85.0821 16.3736 85.2326 16.5594C85.3831 16.7428 85.6136 16.8345 85.9264 16.8345C86.3474 16.8345 86.639 16.6699 86.7942 16.343C86.9518 16.0161 87.0365 15.4705 87.0506 14.7085L89.4824 14.8519C89.4965 14.9601 89.5035 15.1106 89.5035 15.3011C89.5035 16.4582 89.186 17.3237 88.5534 17.8952C87.9208 18.4667 87.0247 18.7536 85.8676 18.7536C84.4777 18.7536 83.504 18.3185 82.9466 17.446C82.3869 16.5735 82.1094 15.2259 82.1094 13.4008V11.2136C82.1094 9.33452 82.3987 7.96105 82.9772 7.09558C83.5558 6.2301 84.5459 5.79736 85.9499 5.79736C86.9165 5.79736 87.6597 5.97375 88.1771 6.32888C88.6945 6.684 89.059 7.23433 89.2707 7.98457C89.4824 8.7348 89.5882 9.76961 89.5882 11.0913V13.2362H84.8657V13.8712ZM85.2232 7.96811C85.0797 8.14449 84.9857 8.43377 84.9363 8.83593C84.8892 9.2381 84.8657 9.84722 84.8657 10.6657V11.5641H86.9283V10.6657C86.9283 9.86133 86.9001 9.25221 86.846 8.83593C86.7919 8.41966 86.6931 8.12803 86.5496 7.95635C86.4062 7.78702 86.1851 7.7 85.8864 7.7C85.5854 7.70235 85.3643 7.79172 85.2232 7.96811Z"></path>      </g>'
}
let timestampsLoaded = false
let secondary
let root
let firstLoad = true
const getProgressBarWidth = () => parseInt(document.querySelector(".ytp-chrome-bottom").style.width)
const getCanvasDivWidth = () => (getProgressBarWidth() + 11) + "px"

let autoHideObserver = new MutationObserver(mutations => {
    if (!alwaysShowHeatmap) return
    if (document.querySelector("#movie_player").classList.contains("ytp-autohide-active")) {
        if (document.querySelector("#movie_player").classList.contains("ytp-autohide")) {
            updateHeatmap = false;
            canvasDiv.style.opacity = "0";
        }
        else {
            heatMapChart.update();
            canvasDiv.style.opacity = "1";
            updateHeatmap = true;
        }
    }

});
let CanvasDivWidthObserver = new MutationObserver(mutations => {
        canvasDiv.style.width = getCanvasDivWidth()
    }
);
const secondaryResizeObserver = new ResizeObserver((entries) => {
    let newWidth = secondary.offsetWidth - 42
    document.querySelector('.blur').style.width = (newWidth < 0 ? "0" : newWidth) + "px"
});

function reset() {
    video = undefined
    Qs = []
    timeout;
    showTimestamps = true
    EditWithNumbers = false
    bar = undefined
    counter = undefined
    updateHeatmap = true
    alwaysShowHeatmap = true
    secondsSplit = undefined
    heatMapChart = undefined
    startOffset = undefined
    isStartOffset = false
    offsetsArr = []
    continuousStamp = undefined
    startPlayDate = 0
    totalPlayTime = 0
    canvasDiv = undefined
    extensionDisabled = false
    autoSaveOn = false
    windowURLIndex = undefined
    tinyMDE = undefined
    isHideMDE = false
    timestampsLoaded = false
    secondary = undefined
    root = undefined

    loadLocalStorage()
    CanvasDivWidthObserver.disconnect()
    autoHideObserver.disconnect()
    secondaryResizeObserver.disconnect()
    if (firstTimestampObserver) {
        firstTimestampObserver.disconnect()
    }
}


// FUNCTIONS
function loadLocalStorage() {
    chrome.storage.local.get("showTimestamps", function (items) {
        if (items["showTimestamps"] !== undefined) {
            if (items["showTimestamps"]) {
                document.querySelector(':root').style.setProperty('--timestamps', '1')
            }
            else {
                document.querySelector(':root').style.setProperty('--after-fade-out', '0')
            }
            showTimestamps = items["showTimestamps"]
        }
        else {
            document.querySelector(':root').style.setProperty('--timestamps', '1')
        }
    });
    chrome.storage.local.get("EditWithNumbers", function (items) {
        if (items["EditWithNumbers"] !== undefined) {
            EditWithNumbers = items["EditWithNumbers"]
        }
    });
    chrome.storage.local.get("alwaysShowHeatmap", function (items) {
        if (items["alwaysShowHeatmap"] !== undefined) {
            alwaysShowHeatmap = items["alwaysShowHeatmap"]
        }
    })
    chrome.storage.local.get("extensionDisabled", function (items) {
        if (items["extensionDisabled"] !== undefined) {
            extensionDisabled = items["extensionDisabled"]
            document.querySelector(':root').style.setProperty('--extension-disabled', extensionDisabled ? '1' : '0')
        }
    });
    chrome.storage.local.get("autoSave", function (items) {
        if (items.autoSave) {
            autoSaveOn = items.autoSave
        }
    })
    chrome.storage.local.get("diffFontSize", function (items) {
        if (items.diffFontSize) {
            document.querySelector(':root').style.setProperty('--diff-font-size', items.diffFontSize)
        }
    })
}
function watchPage() {
    return window.location.pathname === "/watch"
}
function addTotalTimeSpan() {
    let span = document.createElement("span")
    span.innerHTML = "Pause to see"
    span.style.transition = "200ms opacity"
    span.style.opacity = "0"
    span.style.display = "none"
    span.style.paddingLeft = "0.5rem"
    document.querySelector("div.ytp-time-display.notranslate > span:nth-child(2)").onmouseenter = () => {
        span.style.display = ""
        span.style.opacity = "1"
    }
    document.querySelector("div.ytp-time-display.notranslate > span:nth-child(2)").onmouseleave = () => {
        span.style.opacity = "0"
        span.style.display = "none"
    }
    document.querySelector(".ytp-time-display span:nth-child(2)").appendChild(span)
    video.addEventListener('play', ()=>{startPlayDate = new Date();span.innerHTML = "Pause to see"})
    video.addEventListener('pause', () => {
        if (startPlayDate !== 0) {
            totalPlayTime += (new Date() - startPlayDate) / 1000;
        }
        span.innerHTML = `Total: ${formatSeconds(totalPlayTime)}`
    })
}
function listenForRateChange() {
    rate_indicator = document.createElement("p");
    rate_indicator.classList.add("rate_indicator")
    document.querySelector("#ytd-player #container").appendChild(rate_indicator);
    video.addEventListener('ratechange', change_rate_indicator)
}

function turnOnCaptions() {
    if (document.querySelector(".ytp-subtitles-button.ytp-button").getAttribute("aria-pressed") === "false" && document.querySelector(".ytp-subtitles-button-icon").getAttribute("fill-opacity") === '1') {
        document.querySelector(".ytp-subtitles-button.ytp-button").click()
    }
}
function canCloseSecondary() {
    return document.querySelector('#secondary:has([visibility="ENGAGEMENT_PANEL_VISIBILITY_EXPANDED"])') === null && document.querySelector('#chat') === null && document.querySelector('#donate-section') === null
}
function onVideoLoad() {
    waitForElement('#columns').then(() => {
        secondary = document.querySelector("#secondary")
        root = document.querySelector(':root')
        waitAndCreateTinyMDE()
        initFirstTimestampObserver()
        addSecondaryBlurEffect()
    });
}
function replaceVimTubeLogo() {
    document.body.insertAdjacentHTML("beforeend", SVGsDict.vimTubeSvg);
    document.querySelectorAll("link[rel~='icon']").forEach(link => {
        link.href = chrome.runtime.getURL("icon.png")
    });
    waitForElement("#logo #country-code").then(el=>el.textContent = "V2.0")
    waitForElement('#logo-icon > yt-icon-shape > icon-shape > div > svg > svg > g:nth-child(2) > g').then(() => {
        document.querySelector(".external-icon:first-child :nth-child(1) g:last-child").innerHTML = SVGsDict.vimTubeGroupTag;
    });
}

function addShortcutsImages() {
    if (document.querySelector("#scrollable.scrollable") !== null) {
        return
    }
    const imageNames = ["keyboardMap.png", "keyboardMapShift.png", "keyboardMapControl.png"]
    waitForElement("#scrollable").then(() => {
            imageNames.forEach(imageName => {
            let imageEl = document.createElement("img");
            imageEl.src = chrome.runtime.getURL(imageName)
            document.querySelector("#scrollable.scrollable").appendChild(imageEl)
        })
    })
}

function decompressCounter(arrayCompressed) {
    let unCompressed = []
    for (let element of arrayCompressed) {
        if (typeof element === "number") {
            unCompressed.push(element)
        }
        else {
            for (let i of [...Array(Number(element.split("*")[1])).keys()]) {
                unCompressed.push(Number(element.split("*")[0]))
            }
        }
    }
    return unCompressed
}

function compressCounter(arrayUncompressed) {
    let string = arrayUncompressed.toString() + ",";
    let stringCompressed = string.replace(/([\d.]+,)(\1)+/g, (x) => {
        return x.split(",")[0] + "*" + (x.split(",").length - 1) + ",";
    });
    let arrayCompressed = stringCompressed
        .slice(0, -1)
        .split(",")
        .map((x) => (isNaN(Number(x)) ? x : Number(x)));
    return arrayCompressed

}

function listenForLongClickDeleteAllData() {
    let button = document.querySelector(".TMCommandButton:last-child")
    button.oncontextmenu = () => {
        return false
    }
    let timeOutTimer;
    const clickDuration = 2000;
    const deleteOnLongClick =  () => {
        deleteAllPageURLData()
    };
    button.onmousedown = (e) => {
        if (e.which === 3) {
            button.classList.add("red-background")
            timeOutTimer = setTimeout(deleteOnLongClick, clickDuration);
        }
    }
    button.onmouseup = (e) => {
        if (e.which === 3) {
            if (timeOutTimer) {
                clearTimeout(timeOutTimer);
                button.classList.remove("red-background")
            }
        }
    }

}

function deleteAllPageURLData() {
    chrome.storage.local.get("windowUrlDataDict", function (items) {
        let windowUrlDataDict = items.windowUrlDataDict
        windowUrlDataDict.splice(windowURLIndex, 1);
        chrome.storage.local.set({windowUrlDataDict: windowUrlDataDict}).then(r => window.location.reload())
    })

}
function saveHeatmapData() {
    if (!autoSaveOn) {
        return
    }
    chrome.storage.local.get("windowUrlDataDict", function (items) {
        let windowUrlDataDict = items.windowUrlDataDict
        windowUrlDataDict[windowURLIndex].heatmapData = compressCounter(counter);
        chrome.storage.local.set({windowUrlDataDict: windowUrlDataDict}).then(r => {
        })
    })
}

function timestampsDataEquals(timestampsDataArr1, timestampsDataArr2) {
    if (timestampsDataArr1.length !== timestampsDataArr2.length) {
        return false
    }
    const dictEquals = (o1, o2) => Object.keys(o1).length === Object.keys(o2).length
        && Object.keys(o1).every(p => o1[p] === o2[p]);
    for (let i = 0; i < timestampsDataArr1.length; i++) {
        if (!dictEquals(timestampsDataArr1[i], timestampsDataArr2[i])) {
            return false
        }
    }
    return true
}
function loadTimestampsData(timestampsDataArr, savedCounter) {
    timestampsDataArr.forEach(timestamp => {
        if (timestamp.type === "normal") {
            addTimeStamp(undefined, undefined, timestamp.timestampText, timestamp.commentText, timestamp.timestampSec, savedCounter);
        }
        else {
            addContinuousTimeStampBar(undefined, timestamp.type === "skipContinuousStamp", timestamp.startTimestampSec, timestamp.commentText, savedCounter)
            addContinuousTimeStampBar(undefined, timestamp.type === "skipContinuousStamp", timestamp.endTimestampSec, timestamp.commentText, savedCounter)
        }
    })
    setTimeout(() => {
        timestampsLoaded = true
        root.style.setProperty('--timestamps-before-load', '0')
    }, 100);
}

function saveTimestampsData() {
    if (!autoSaveOn || !timestampsLoaded) {
        return
    }
    let dataArr = getTimestampsData();
    chrome.storage.local.get("windowUrlDataDict", function (items) {
        let windowUrlDataDict = items.windowUrlDataDict
        if (timestampsDataEquals(windowUrlDataDict[windowURLIndex].timestampsData, dataArr)) {
            return
        }
        windowUrlDataDict[windowURLIndex].timestampsData = dataArr;
        chrome.storage.local.set({windowUrlDataDict: windowUrlDataDict})
    })
}

function getTimestampsData() {
    let dataArr = [];
    document.querySelectorAll(".timestamps-container").forEach((e) => {
        let commentText = e.querySelector(".input-timestamp").value
        let h1StartText = e.querySelector("h1[time]").textContent
        let h1StartSec = Number(e.querySelector("h1[time]").getAttribute("time"))
        if (e.classList.contains("timestamps-container-chapter")) {
            let h1EndText = e.querySelector("h1[endtime]").textContent;
            let h1EndSec = Number(e.querySelector("h1[endtime]").getAttribute("endTime"));
            let timestampType
            if (e.classList.contains("timestamps-container-chapter-skip")) {
                timestampType = "skipContinuousStamp"
            }
            else {
                timestampType = "continuousStamp"
            }
            dataArr.push({startTimestampText: h1StartText, startTimestampSec: h1StartSec, endTimestampTime: h1EndText,
                endTimestampSec: h1EndSec, commentText: commentText, type: timestampType})
        }
        else {
            dataArr.push({timestampText: h1StartText, timestampSec: h1StartSec, commentText: commentText, type: "normal"})
        }
    })
    return dataArr
}

let firstTimestampObserver
function initFirstTimestampObserver() {
    firstTimestampObserver = new IntersectionObserver(firstTimestampIntersection, {
        root: secondary,
        threshold: .7
    })
}
function firstTimestampIntersection(entries) {
    if (entries[0].isIntersecting) {
        document.querySelector(".blur").classList.remove("blur-top")
        secondary.classList.remove("blur-top");
    }
    else if(secondary.scrollHeight > secondary.clientHeight && timestampsLoaded){
        document.querySelector(".blur").classList.add("blur-top")
        secondary.classList.add("blur-top")
    }
}
function addFirstTimestampObserver() {
    firstTimestampObserver.disconnect()
    firstTimestampObserver.observe(document.querySelector("#secondary > div:nth-child(1)"))
}

function addSecondaryBlurEffect() {
    let blurWrapper = document.createElement("div")
    blurWrapper.classList.add("zero-space-wrapper")
    let blurEl = document.createElement("div")
    blurEl.classList.add("blur")
    blurWrapper.appendChild(blurEl)
    document.querySelector("#columns").insertBefore(blurWrapper, secondary);
    secondaryResizeObserver.observe(secondary)
}
function handleAddTimeStampIfEmpty(start, noTimeStamps) {
    if (!start) {
        let newWidth = secondary.offsetWidth - 42
        document.querySelector('.blur').style.width = (newWidth < 0 ? "0" : newWidth) + "px"
        addFirstTimestampObserver()
    }
    const totalPadding = parseInt(window.getComputedStyle(document.documentElement).getPropertyValue('--ytd-margin-6x'))
        + parseInt(window.getComputedStyle(document.documentElement).getPropertyValue('font-size'));
    if (secondary.offsetWidth !==  totalPadding) {
        if (showTimestamps) {
            root.style.setProperty('--after-fade-out', '1');
        }
        dispatchEventInputs()
        return;
    }
    if (!(noTimeStamps && showTimestamps)) {
        return;
    }
    if (start) {
        secondary.style.animation = "";
        root.style.setProperty('--timestamps', '0');
        root.style.setProperty('--after-fade-out', '0')
    }
    else {
        secondary.style.setProperty("width", "auto", "important");
        root.style.setProperty('--timestamps', '1');
        root.style.setProperty('--after-fade-out', '1')
        if (canCloseSecondary()) {
            secondary.style.animation = "max-width-animate 250ms  cubic-bezier(0, 0, 0.88, 0.15)";
        }
        setTimeoutDispatchEventInput()
    }

}
function waitAndCreateTinyMDE() {
    let tinyMDEInterval = setInterval(checkTinyMDEDefined, 10);
    function checkTinyMDEDefined() {
        if (TinyMDE !== undefined) {
            clearInterval(tinyMDEInterval);
            createTinyMDE()
        }
    }
}
function handleModifierKeyAddTimeStamp(e, input) {
    if (e === undefined) {return;}
    if (e.shiftKey) {
        e.preventDefault();
        input.value = '';
        input.dispatchEvent(new Event("input"));
        setTimeout(() => {
            input.focus()
        }, 10);
        return
    }
    else if (e.ctrlKey && document.querySelector(".captions-text") !== null) {
        input.value = document.querySelector(".captions-text").innerText.replaceAll("\n", " ");
        input.dispatchEvent(new Event("input"));
    }
    adjustInputsValue()
}
function addSecondaryListeners() {
    secondary.oncontextmenu = () => {return false}
    secondary.onmousedown = (e) => {
        if (e.button === 2) {
            if (e.target.id !== "secondary") return;
            EditWithNumbers = !EditWithNumbers
            chrome.storage.local.set({ "EditWithNumbers": EditWithNumbers });
        }
    }
    document.querySelector(".ytp-chrome-bottom").onmousedown = (e) => {
        if (e.which === 3) {
            root.style.setProperty('--hide-ytp-contextmenu', '1')
            setTimeout(() => {
                root.style.setProperty('--hide-ytp-contextmenu', '0')
            }, 100);
        }
    }
}
function adjustInputWidth(inputEl, spanEl) {
    spanEl.textContent = inputEl.value;
    if (/^\d$/.test(inputEl.value)) {
        inputEl.style.width = spanEl.offsetWidth - 11 + 'px';
    }
    else {
        inputEl.style.width = spanEl.offsetWidth - 7 + 'px';
    }
}
function addInputListeners(inputEl) {
    inputEl.dir = "auto"
    inputEl.addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
            e.target.blur()
        }
    });
    inputEl.oninput = (e) => {
        adjustInputWidth(e.target, e.target.nextElementSibling)
        saveTimestampsData()
    }
    inputEl.addEventListener("click", function () {
        if (!isNaN(this.value) || this.value === '') {
            this.setSelectionRange(0, this.value.length)
        }
    });
}

function handleNumbers(e) {
    e.stopPropagation();
    e.preventDefault()
    let h1AtIndex = document.querySelectorAll("h1[time]")[e.which - 49]
    if (h1AtIndex !== undefined) {
        if (e.ctrlKey) {
            if (h1AtIndex.parentElement.classList.contains("timestamps-container-chapter")) {
                removeContinuousTimestamp(h1AtIndex.getAttribute("time"))
            }
            else {
                removeTimestamp(h1AtIndex.getAttribute("time"))
            }
            return;
        }
        if (e.shiftKey) {
            EditWithNumbers = !EditWithNumbers
        }
        if (EditWithNumbers) {
            let inputNumber = document.querySelectorAll("input[time]")[e.which - 49]
            inputNumber.focus()
            if (!isNaN(inputNumber.value) || inputNumber.value === '') {
                inputNumber.setSelectionRange(0, inputNumber.value.length)
            }
        }
        else {
            h1AtIndex.click()
        }
        if (e.shiftKey) {
            EditWithNumbers = !EditWithNumbers
        }
    }

}

function toggleExtensionDisabled(e) {
    e.preventDefault()
    extensionDisabled = !extensionDisabled
    root.style.setProperty('--extension-disabled', extensionDisabled ? '1' : '0')
    chrome.storage.local.set({"extensionDisabled": extensionDisabled});
}
function toggleFocusEditor(e) {
    if (isInInput(e)) {
        document.activeElement.blur()
    }
    else {
        tinyMDE.paste("");
    }
}
function createTinyMDE() {
    let secondaryDivClone = document.createElement('div')
    let commandBarDiv = document.createElement('div')
    let tinymdeDiv = document.createElement('div')
    secondaryDivClone.classList.add("tinymde-container")
    secondaryDivClone.style.display = "none"
    secondaryDivClone.setAttribute("dir", "ltr")
    commandBarDiv.setAttribute("id", "tinymde_commandbar");
    tinymdeDiv.setAttribute("id", "tinymde");
    document.querySelector("#columns").appendChild(secondaryDivClone)
    secondaryDivClone.appendChild(commandBarDiv)
    secondaryDivClone.appendChild(tinymdeDiv)
    tinyMDE = new TinyMDE.Editor({element: 'tinymde'});
    const commandBar = new TinyMDE.CommandBar({
        element: 'tinymde_commandbar',
        editor: tinyMDE,
        commands: [{
            name: 'h1',
            hotkey: 'Alt-A',
        }, {
            name: 'h2',
            hotkey: 'Alt-S',
        }, "|", 'bold', 'hr',
            "|", 'ol', 'ul', "|",
             {
                name: 'fontIncrease',
                action: editor => {
                    if (document.querySelector('.TMCommandButton_Inactive[title="Increase Font Size"]')) {return}
                    let newFontSize = parseInt(window.getComputedStyle(document.documentElement).getPropertyValue('--diff-font-size')) + 1 + "px"
                    root.style.setProperty('--diff-font-size', newFontSize);
                    chrome.storage.local.set({diffFontSize: newFontSize})
                    editor.fireSelection()
                },
            }, {
                name: 'fontDecrease', action: editor => {
                    if (document.querySelector('.TMCommandButton_Inactive[title="Decrease Font Size"]')) {return}
                    let newFontSize = parseInt(window.getComputedStyle(document.documentElement).getPropertyValue('--diff-font-size')) - 1 + "px"
                    root.style.setProperty('--diff-font-size', newFontSize);
                    chrome.storage.local.set({diffFontSize: newFontSize})
                    editor.fireSelection()
                },
            }, "|",
            {
                name: 'showHideTimestamps',
                action: showHideTimestamps

            },
            {
                name: 'save',
                action: editor => {
                    autoSaveOn = !autoSaveOn
                    editor.fireSelection();
                    document.querySelector(".TinyMDE").dispatchEvent(new Event("input"));
                    chrome.storage.local.set({autoSave: autoSaveOn})
                    if (autoSaveOn) {
                        saveTimestampsData();
                        saveHeatmapData()
                    }
                },
                hotkey: 'Mod-s'
            },
        ]
    });
    document.querySelector("#tinymde").setAttribute("dir", "auto")
    tinyMDE.fireSelection();


    tinyMDE.addEventListener('change', e => {
        if (autoSaveOn) {
            chrome.storage.local.get("windowUrlDataDict", function (items) {
                let windowUrlDataDict = items.windowUrlDataDict
                windowUrlDataDict[windowURLIndex].TinyMDEText = e.content
                chrome.storage.local.set({windowUrlDataDict: windowUrlDataDict})
            })
        }
    });


    chrome.storage.local.get("isHideMDE", function (items) {
        if (!items.isHideMDE) {
            document.querySelector(".tinymde-container").style.display = ""
            document.querySelector(".tinymde-container").style.animation = "scale-to-1 200ms ease-in-out forwards"
        }
    })

    chrome.storage.local.get("windowUrlDataDict", function (items) {
        let windowUrlDataDict = items.windowUrlDataDict
        let exists = false
        const videoID = new URLSearchParams(window.location.search).get("v")
        for (let i in windowUrlDataDict) {
            if (windowUrlDataDict[i].url === videoID) {
                windowURLIndex = i
                tinyMDE.setContent(windowUrlDataDict[i].TinyMDEText)
                addHeatMap(decompressCounter(windowUrlDataDict[i].heatmapData))
                loadTimestampsData(windowUrlDataDict[i].timestampsData, decompressCounter(windowUrlDataDict[i].heatmapData))
                exists = true
                break;
            }
        }
        if (!exists) {
            if (windowUrlDataDict === undefined) {
                windowUrlDataDict = []
            }
            windowURLIndex = windowUrlDataDict.length
            windowUrlDataDict.push({url: videoID, TinyMDEText: "", timestampsData: [], heatmapData: []})
            chrome.storage.local.set({windowUrlDataDict: windowUrlDataDict})
            addHeatMap(undefined)
            timestampsLoaded = true
            root.style.setProperty('--timestamps-before-load', '0')
        }
    })
    window.addEventListener('keydown', logKey, true);
    listenForLongClickDeleteAllData()

}

function isCommentDigit(comment) {
    return /^\d{1,3}$/.test(comment)
}
function h1OnMouseDown(e, isContinuousTimeStamp, isSecondH1) {
    if (e.button === 2) {
        e.preventDefault();
        let toPaste = tinyMDE.getContent() === '' ? "" : "\n"
        if (isContinuousTimeStamp) {
            if (!isSecondH1) {
                let comment = e.target.nextSibling.value
                toPaste += (isCommentDigit(comment) ? comment : "") + (isCommentDigit(comment) ? ". " : "") + e.target.innerHTML + "-" + e.target.previousSibling.previousSibling.innerHTML
            }
            else {
                let comment = e.target.nextSibling.nextSibling.nextSibling.value
                toPaste += (isCommentDigit(comment) ? comment : "") + (isCommentDigit(comment) ? ". " : "") + e.target.nextSibling.nextSibling.innerHTML + "-" + e.target.innerHTML
            }
        }
        else {
            let comment = e.target.nextSibling.value
            toPaste += (isCommentDigit(comment) ? comment : "") + (isCommentDigit(comment) ? ". " : "") + e.target.innerHTML
        }
        toPaste += " - "
        tinyMDE.paste(toPaste);
        tinyMDE.setSelection(tinyMDE.getSelection())
    }
}
function h1OnClick(e, attribute) {
    video.currentTime = (e.target.getAttribute(attribute))
    e.target.style.setProperty("transition", "color 30ms linear 0s, text-color 30ms linear 0s, transform ease-out 80ms");
    e.target.style.setProperty("color", "hsl(210 100% 100% / 1)", "important");
    e.target.style.setProperty("textShadow", "hsl(210 100% 100% / 1) 0px 0px 7px", "important");
    e.target.style.setProperty("transform", "scale(1.1)", "important");
    setTimeout(() => {
        e.target.style.setProperty("transition", "color 700ms cubic-bezier(0.43, 0, 0, 1) 0s, text-color 700ms cubic-bezier(0.43, 0, 0, 1) 0s, transform cubic-bezier(0.43, 0, 0, 1) 300ms");
        e.target.style.setProperty("color", "rgb(71, 163, 255)");
        e.target.style.setProperty("textShadow", "rgb(3, 169, 244) 0px 0px 7px");
        e.target.style.setProperty("transform", "scale(1)", "important");
    }, 100)
}
function inSkipOffset(currentTime) {
    let currentOffset = currentTime / video.duration * 100
    for (let i = 0; i < offsetsArr.length; i++) {
        if ((currentOffset >= offsetsArr[i][0] && currentOffset <= offsetsArr[i][1])) {
            if (document.querySelector(`[startoffset="${offsetsArr[i][0]}"]`) && document.querySelector(`[startoffset="${offsetsArr[i][0]}"]`).classList.contains("__youtube-timestamps__stamp__chapter__skip")) {
                return true
            }
        }
    }
    return false
}
function skipIfInSkipOffset() {
      let currentOffset = video.currentTime / video.duration * 100
        for (let i = 0; i < offsetsArr.length; i++) {
            if ((currentOffset >= offsetsArr[i][0] && currentOffset <= offsetsArr[i][1])) {
                if (document.querySelector(`[startoffset="${offsetsArr[i][0]}"]`) && document.querySelector(`[startoffset="${offsetsArr[i][0]}"]`).classList.contains("__youtube-timestamps__stamp__chapter__skip")) {
                    video.currentTime = (offsetsArr[i][1] * video.duration / 100) + 0.01
                }
                break
            }
        }
}

function updateBorderColors(){
    let counterClipped = counter.map(value=>{return Math.min(value/secondsSplit/4, 4)})
    document.querySelectorAll(".timestamps-container:not(.timestamps-container-chapter) h1").forEach((e) => {
        let borderColor = Math.max((120-(counter[Math.round(parseFloat(e.getAttribute("time")) / secondsSplit)] / secondsSplit / 4 / 4) * 120) - 10, 0)
        e.parentElement.querySelector("hr").style.borderRight = `2px hsl(${borderColor}deg 80% 50%) solid`
        e.parentElement.style.border = `1px hsl(${borderColor}deg 80% 50%) solid`
    })


    document.querySelectorAll(".timestamps-container-chapter:not(.timestamps-container-chapter-skip)").forEach((e) => {
        let startTimeSeconds = e.querySelector("h1[startTime]").getAttribute("startTime")
        let endTimeSeconds = e.querySelector("h1[endTime]").getAttribute("endTime")
        let list = counterClipped.slice(Math.floor(startTimeSeconds / secondsSplit), Math.ceil(endTimeSeconds / secondsSplit))
        let average = list.reduce((prev, curr) => prev + curr) / list.length;
        let borderColor = Math.max((120-(average / 4) * 120) - 10, 0)
        e.querySelector("hr").style.borderRight = `2px hsl(${borderColor}deg 80% 50%) solid`
        e.style.border = `1px hsl(${borderColor}deg 80% 50%) solid`
    })
}


function addContinuousTimeStamp(e, startTime, endTime, isSkip, inputText, savedCounter) {
    let counterForBorder = savedCounter !== undefined ? savedCounter : counter
    let noTimeStamps = document.querySelector(".timestamps-container") === null;
    handleAddTimeStampIfEmpty(true, noTimeStamps)
    let counterClipped = counterForBorder.map(value=>{return Math.min(value/secondsSplit/4, 4)})
    let list = counterClipped.slice(Math.floor(startTime / secondsSplit), Math.ceil(endTime / secondsSplit))
    let average = list.reduce((prev, curr) => prev + curr) / list.length;
    let borderColor = Math.max((120-(average / 4) * 120) - 10, 0)

    startTime = startTime.toFixed(1)
    endTime = endTime.toFixed(1)

    let h1 = document.createElement("h1")
    let h1Second = document.createElement("h1")
    let h1Divider = document.createElement("h1")
    h1Divider.innerHTML = "-"
    h1Divider.classList.add("h1-divider")
    h1.classList.add("h1-timestamp")
    h1Second.classList.add("h1-timestamp")
    h1.setAttribute("startTime", startTime)
    h1.setAttribute("time", startTime)
    h1Second.setAttribute("endTime", endTime)
    h1.innerHTML = formatSeconds(startTime)
    h1Second.innerHTML = formatSeconds(endTime)
    h1.onclick = (e) => h1OnClick(e, "startTime")
    h1.onmousedown = (e) => h1OnMouseDown(e, true, false)
    h1Second.onclick = (e) => h1OnClick(e, "endTime")
    h1Second.onmousedown = (e) => h1OnMouseDown(e, true, true)
    let span = document.createElement("span")
    span.classList.add("measure")
    let input = document.createElement("input")
    input.classList.add("input-timestamp")
    input.setAttribute("time", startTime)
    if (inputText !== undefined) {
        input.value = inputText
        adjustInputWidth(input, span)
    }
    addInputListeners(input)
    let svg = document.createElement("svg")
    svg.setAttribute("time", startTime)
    svg.classList.add("svg-timestamp")
    svg.innerHTML = SVGsDict.trashSvg
    svg.setAttribute("time", startTime)
    let hr = document.createElement("hr")
    hr.classList.add("hr-timestamp")
    let br = document.createElement("br")
    br.setAttribute("time", startTime)
    let container = document.createElement("div")
    container.classList.add("timestamps-container")
    container.classList.add("timestamps-container-chapter")
    if (isSkip) {
        container.classList.add("timestamps-container-chapter-skip");
    }
    else{
        hr.style.borderRight = `2px solid hsl(${borderColor}deg 80% 50%)`;
        container.style.border = `1px hsl(${borderColor}deg 80% 50%) solid`
    }
    secondary.insertBefore(container, document.querySelector("#secondary-inner"));
    container.appendChild(svg)
    container.appendChild(hr)
    container.appendChild(h1Second)
    container.appendChild(h1Divider)
    container.appendChild(h1)
    container.appendChild(input)
    container.appendChild(span)
    container.appendChild(br)
    svg.firstChild.firstChild.onclick = (e) => {
        let timeAttribute = e.target.closest(".svg-timestamp").getAttribute("time")
        let continuousTimeStamp = document.querySelector(`.__youtube-timestamps__stamp__chapter[startTime="${timeAttribute}"]`)

        continuousTimeStamp.style.animation = "scale-to-0 200ms ease-in-out forwards"
        setTimeout(() => {
            continuousTimeStamp.remove()
        }, 200);


        removeContinuousTimestamp(timeAttribute)
    }
    addSecondaryListeners()
    handleModifierKeyAddTimeStamp(e, input)
    handleAddTimeStampIfEmpty(false, noTimeStamps)
    saveTimestampsData();
}

function addContinuousTimeStampBar(e, isSkip, timestampSec, inputText, savedCounter) {
    if (e !== undefined) {
        e.preventDefault();
        e.stopPropagation()
    }
    let currentTime
    if (document.querySelector(".ytp-fine-scrubbing-container").style.height !== "") {
        currentTime = getCurrentTimeScrubbing()
    }
    else if (timestampSec === undefined) {
        currentTime =  video.currentTime
    }
    else{
        currentTime = timestampSec
    }
    if (isStartOffset) {
        let endOffset = Number((currentTime / video.duration * 100).toFixed(1))
        let width
        let flipped = false
        if (endOffset === startOffset) return
        else if (endOffset < startOffset) {
            [startOffset, endOffset] = [endOffset, startOffset];
            flipped = true
        }
        width = endOffset - startOffset
        offsetsArr.push([startOffset, endOffset])


        let intersections = 0, i;
        offsetsArr.sort(function (a, b) {
            return a[0] - b[0];
        });
        for (i = 1; i < offsetsArr.length; i++) {
            if (offsetsArr[i][0] < offsetsArr[i - 1][1]) {
                intersections++;
            }
        }
        if (intersections > 0) {
            offsetsArr.splice(offsetsArr.findIndex((arr) => JSON.stringify(arr) === JSON.stringify([startOffset, endOffset])), 1);
            if (flipped) {
                [startOffset, endOffset] = [endOffset, startOffset];
            }
            return
        }
        continuousStamp.style.width = `calc(${width}% + 2px)`
        continuousStamp.setAttribute("startOffset", startOffset)
        continuousStamp.setAttribute("endOffset", endOffset)
        continuousStamp.style.left = `calc(${startOffset}% - 2px)`
        continuousStamp.style.animation = 'none'
        continuousStamp.setAttribute("startTime", (startOffset * video.duration / 100).toFixed(1))
        continuousStamp.setAttribute("endTime", (endOffset * video.duration / 100).toFixed(1))
        isStartOffset = false
        addContinuousTimeStamp(e, startOffset * video.duration / 100, endOffset * video.duration / 100, continuousStamp.classList.contains("__youtube-timestamps__stamp__chapter__skip"), inputText, savedCounter)

    }
    else {
        startOffset = Number((currentTime / video.duration * 100).toFixed(1))
        for (let i = 0; i < offsetsArr.length; i++) {
            if ((startOffset >= offsetsArr[i][0] && startOffset <= offsetsArr[i][1])) {
                return
            }
        }
        isStartOffset = true

        continuousStamp = document.createElement('div')
        continuousStamp.classList.add('__youtube-timestamps__stamp')
        continuousStamp.classList.add('__youtube-timestamps__stamp__chapter')
        if (isSkip) {
            continuousStamp.classList.add('__youtube-timestamps__stamp__chapter__skip')
        }
        continuousStamp.style.left = `calc(${startOffset}% - 2px)`
        continuousStamp.style.maxWidth = "100%"
        continuousStamp.style.width = `2px`
        continuousStamp.style.borderRadius = "0"
        continuousStamp.style.top = "-1px"
        continuousStamp.style.backgroundColor = "hsl(60deg 100% 50% / 80%)"
        continuousStamp.style.animation = 'scale-anim 1000ms infinite'
        continuousStamp.onmousedown = (e) => {
            if (e.button === 2) {
                root.style.setProperty('--ytp-contextmenu-display', 'none')
                e.target.style.animation = "scale-to-0 200ms ease-in-out forwards"
                setTimeout(() => {
                    if (e.target.getAttribute("endTime")){
                        removeContinuousTimestamp(e.target.getAttribute("startTime"))

                    }
                    else{
                        isStartOffset = false
                    }
                    root.style.setProperty('--ytp-contextmenu-display', '')
                }, 200);
            }
        }
        bar = getOrCreateBar()
        document.querySelector(".__youtube-timestamps__bar").oncontextmenu = () => { return false }
        bar.appendChild(continuousStamp)

    }
}

function addHeatMap(savedCounter) {
    secondsSplit = Math.ceil(Math.sqrt(video.duration)/4)
    console.log("Adding HeatMap With " + secondsSplit + " Seconds Precision")
    const tickSpeed = 4
    const maxTimesWatched = 4
    counter = new Array(Math.ceil(video.duration / secondsSplit)+1).fill(0);
    document.querySelector(".ytp-progress-bar").oncontextmenu = () => {return false}
    document.querySelector(".ytp-progress-bar-container").oncontextmenu = () => {return false}



    let canvasDivWrapper = document.createElement("div")
    canvasDivWrapper.classList.add("zero-space-wrapper")
    canvasDiv = document.createElement("div")
    canvasDiv.style.width = getCanvasDivWidth()
    canvasDiv.id = "canvas-div"
    if (!alwaysShowHeatmap) {
        canvasDiv.style.opacity = "0";
    }
    canvasDiv.innerHTML = '<canvas id="heatmap-chart" style="width: 100%;height:6rem;position:relative;" class="chartjs-render-monitor"></canvas>'
    canvasDivWrapper.appendChild(canvasDiv)
    document.querySelector(".ytp-progress-bar").appendChild(canvasDivWrapper)



    autoHideObserver.observe(document.querySelector("#movie_player"), {
        attributes: true,
        attributeFilter: ["class"]
    });


    CanvasDivWidthObserver.observe(document.querySelector(".ytp-chrome-bottom"), {
        attributes: true,
        attributeFilter: ["style"]
    });

    document.querySelector(".ytp-progress-bar").onmouseenter = () =>{
        if (alwaysShowHeatmap) return
        heatMapChart.update();
        canvasDiv.style.opacity = "1"
        updateHeatmap = true
    }
    document.querySelector(".ytp-progress-bar").onmouseleave = () =>{
        if (alwaysShowHeatmap) return
        canvasDiv.style.opacity = "0"
        updateHeatmap = false
    }
    let canvas = document.getElementById('heatmap-chart')
    let ctx = canvas.getContext("2d");
    let gradientStroke = ctx.createLinearGradient(0, canvas.scrollHeight, 0, 0);
    gradientStroke.addColorStop(0.5, 'hsl(60 80% 50% / 0.6)');
    gradientStroke.addColorStop(0.8, 'hsl(0 80% 50% / 0.6)');
    gradientStroke.addColorStop(0, 'transparent');
    gradientStroke.addColorStop(0.22, 'transparent');
    gradientStroke.addColorStop(0.22, 'hsl(120 80% 50% / 0.6)');



    const data = {
      labels: Array.from(Array(counter.length + 1).keys()).map(String),
      datasets: [{
        borderWidth: 2,
        backgroundColor: gradientStroke,
        borderColor: gradientStroke,
        pointBorderColor: gradientStroke,
        pointBackgroundColor: gradientStroke,
        pointHoverBackgroundColor: gradientStroke,
        pointHoverBorderColor: gradientStroke,
        label: 'Heat Map',
        data: counter,
        fill: true,
        tension: 0.5,
        pointRadius: 0,
        pointHoverRadius: 10,
      }]
    };
    const config = {
        maintainAspectRatio: false,
        responsive: true,
        type: 'line',
        legend: {
            display: false
        },
        tooltips: {
            enabled: false
        },
        data: data,
        scales: {
            xAxes: [{
                display: true,
                ticks: {
                    display: false,
                    fontColor: 'rgba(255,255,255,0.6)',
                    fontSize: 9,
                    beginAtZero: true,
                },
                gridLines: {
                    display: false
                }
            }],
            yAxes: [{
                display: true,
                ticks: {
                    display: false,
                    fontColor: 'rgba(255,255,255,0.6)',
                    beginAtZero: true,
                    max: 4,
                },
                gridLines: {
                    display: false
                }
            }]
        }
    };

    heatMapChart = new Chart("heatmap-chart", {
      type: "line",
      data:data,
      options: config
    });

    setTimeout(() => {
        if (savedCounter !== undefined && savedCounter.length !== 0) {
            counter = counter.map(function (num, idx) {
                return num + savedCounter[idx];
            })
            heatMapChart.data.labels = Array.from(Array(counter.length).keys()).map(String)
            heatMapChart.data.datasets[0].data = counter.map(value => {
                return value / (secondsSplit * tickSpeed)
            }).map(value => value > maxTimesWatched - 0.2 ? maxTimesWatched - 0.2 : value)
            heatMapChart.update();
        }
        video.ontimeupdate = (e) => {
            if (counter === undefined) {
                return;
            }
            skipIfInSkipOffset();
            if (video.paused) return
            let currentTimeFloor = Math.floor(video.currentTime / secondsSplit)
            let currentTimeCeil = Math.ceil(video.currentTime / secondsSplit)
            counter[currentTimeFloor] += video.playbackRate / 2;
            counter[currentTimeCeil] += video.playbackRate / 2;
            saveHeatmapData()
            heatMapChart.data.labels = Array.from(Array(counter.length).keys()).map(String)
            heatMapChart.data.datasets[0].data = counter.map(value=>{return value/(secondsSplit*tickSpeed)}).map(value => value > maxTimesWatched-0.2? maxTimesWatched-0.2:value)
            updateBorderColors()
            if (updateHeatmap){
                heatMapChart.update();
            }
        }

    }, 500);




}
function formatSeconds(seconds) {
    const d = Math.floor(seconds / (24 * 60 * 60));
    const ds = seconds % (24 * 60 * 60);
    const h = Math.floor(ds / (60 * 60));
    const hs = seconds % (60 * 60);
    const m = Math.floor(hs / (60));
    const ms = seconds % (60);
    const s = Math.floor(ms);
    const pad = (el) => el.toString().padStart(2, '0')
    let formatted = ""
    if (d !== 0) {
        formatted += d + ":"
    }
    if (h !== 0) {
        formatted += pad(h) + ":"
    }
    return formatted + pad(m) + ":" + pad(s);
}
function getCurrentTimeScrubbing() {
    let currentTime
    let timeArr = document.querySelector(".ytp-time-current").textContent.split(':')
    if (timeArr.length <= 3) {
        currentTime = timeArr.reduce((acc, time) => (60 * acc) + +time);
    }
    else {
        currentTime = timeArr.shift() * 60 * 60 * 24
        currentTime += timeArr.reduce((acc, time) => (60 * acc) + +time);
    }
    return currentTime
}
function addTimeStamp(e, timestampsContainerAnimation, h1Text, inputText, timestampSec, savedCounter){
    let noTimeStamps = document.querySelector(".timestamps-container") === null
    let currentTime
    if (document.querySelector(".ytp-fine-scrubbing-container").style.height !== "") {
        currentTime = getCurrentTimeScrubbing()
    }
    else if (timestampSec === undefined) {
        currentTime = Number((video.currentTime).toFixed(1))
    }
    else{
        currentTime = timestampSec
    }
    if (inSkipOffset(currentTime)) {
        return;
    }
    if (Qs.includes(currentTime)) return;
    handleAddTimeStampIfEmpty(true, noTimeStamps)
    Qs.push(currentTime)
    console.log(
        `%c${formatSeconds(video.currentTime)}`,
        ` color:cyan; background-color:black; border-left: 1px solid yellow; padding: 1px;`
    );
    let stamp = document.createElement('div')
    stamp.classList.add('__youtube-timestamps__stamp')
    let offset = currentTime / video.duration * 100
    stamp.style.left = `calc(${offset}% - 2px)`
    stamp.style.top = "-1px"
    stamp.setAttribute("time", currentTime)
    stamp.onmouseenter = () => {document.querySelector(".ytp-progress-bar").style.pointerEvents = "none"}
    stamp.onmouseleave = () => {setTimeout(() => {document.querySelector(".ytp-progress-bar").style.pointerEvents = ""}, 25)}
    stamp.onclick = (e) => {document.querySelector(`h1[time="${e.target.getAttribute("time")}"]`).click()}
    stamp.onmousedown = (e) => {
        if (e.button === 2) {
            root.style.setProperty('--ytp-contextmenu-display', 'none')
            document.querySelector(`.__youtube-timestamps__stamp[time="${e.target.getAttribute("time")}"]`).style.animation = "scale-to-0 200ms ease-in-out forwards"
            setTimeout(() => {
                removeTimestamp(e.target.getAttribute("time"))
                root.style.setProperty('--ytp-contextmenu-display', '')
            }, 200);
        }
    }
    bar = getOrCreateBar()
    document.querySelector(".__youtube-timestamps__bar").oncontextmenu = () => {return false}
    bar.appendChild(stamp)
    let counterForBorder = savedCounter !== undefined ? savedCounter : counter
    let borderColor = Math.max((120-(counterForBorder[Math.round(currentTime / secondsSplit)] / secondsSplit / 4 / 4) * 120) - 10, 0)
    let h1 = document.createElement("h1")
    h1.classList.add("h1-timestamp")
    h1.setAttribute("time", currentTime)
    if (document.querySelector(".ytp-fine-scrubbing-container").style.height !== "") {
        h1.innerHTML = document.querySelector(".ytp-time-current").textContent
    }
    else if (h1Text === undefined) {
        h1.innerHTML = formatSeconds(video.currentTime);
    }
    else {
        h1.innerHTML = h1Text
    }
    h1.onclick = (e) => h1OnClick(e, "time");
    h1.onmousedown = (e) => h1OnMouseDown(e, false, false)
    let span = document.createElement("span")
    span.classList.add("measure")
    let input = document.createElement("input")
    input.classList.add("input-timestamp")
    input.setAttribute("time", currentTime)
    if (inputText !== undefined) {
        input.value = inputText
        adjustInputWidth(input, span)
    }
    addInputListeners(input)
    let svg = document.createElement("svg");
    svg.setAttribute("time", currentTime)
    svg.classList.add("svg-timestamp")
    svg.innerHTML = SVGsDict.trashSvg
    svg.setAttribute("time", currentTime)
    let hr = document.createElement("hr")
    hr.classList.add("hr-timestamp")
    let br = document.createElement("br")
    br.setAttribute("time", currentTime)
    let container = document.createElement("div")
    container.classList.add("timestamps-container")
    container.style.border = `1px hsl(${borderColor}deg 80% 50%) solid`
    hr.style.borderRight = `2px solid hsl(${borderColor}deg 80% 50%)`
    if (timestampsContainerAnimation !== undefined){
        container.style.animation = timestampsContainerAnimation
    }
    secondary.insertBefore(container, document.querySelector("#secondary-inner"));
    container.appendChild(svg)
    container.appendChild(hr)
    container.appendChild(h1)
    container.appendChild(input)
    container.appendChild(span)
    container.appendChild(br)
    svg.firstChild.firstChild.onclick = (e) => {
        let timeAttribute = e.target.closest(".svg-timestamp").getAttribute("time")
        removeTimestamp(timeAttribute)
    }
    addSecondaryListeners()
    handleModifierKeyAddTimeStamp(e, input)
    handleAddTimeStampIfEmpty(false, noTimeStamps)
    saveTimestampsData();
}
async function removeContinuousTimestamp(startTime){
    let continuousTimeStamp = document.querySelector(`.__youtube-timestamps__stamp__chapter[startTime="${startTime}"]`)
    let startOffset = continuousTimeStamp.getAttribute("startOffset")
    let endOffset = continuousTimeStamp.getAttribute("endOffset")
    let endTime = continuousTimeStamp.getAttribute("endTime")
    continuousTimeStamp.style.animation = "scale-to-0 200ms ease-in-out forwards"
    let timestampsContainer = document.querySelector(`.timestamps-container-chapter:has([time='${startTime}'])`)
    timestampsContainer.style.animation = "scale-to-0-remove-timestamp 200ms ease-in-out forwards"
    handleWidthRemoveTimestamp(timestampsContainer)

    await new Promise(r => setTimeout(r, 200));
    offsetsArr.splice(offsetsArr.findIndex((arr) => JSON.stringify(arr) === JSON.stringify([parseFloat(startOffset), parseFloat(endOffset)])), 1);
    document.querySelectorAll(`.timestamps-container-chapter [time="${startTime}"]`).forEach((e)=>{e.remove()})
    document.querySelectorAll(`.timestamps-container-chapter [endTime="${endTime}"]`).forEach((e)=>{e.remove()})
    document.querySelectorAll(`.__youtube-timestamps__stamp__chapter[endTime="${endTime}"]`).forEach((e)=>{e.remove()})
    document.querySelectorAll(".timestamps-container-chapter:not(:has([time]))").forEach((e)=>{e.remove()})
    adjustInputsValue()
    saveTimestampsData()
    addFirstTimestampObserver()
}

function handleWidthRemoveTimestamp(container){
    if (document.querySelectorAll(".timestamps-container").length === 1) {
        secondary.style.animation = "";
        setTimeout(() => {
            root.style.setProperty('--after-fade-out', '0')
        }, 200)
        if (canCloseSecondary()) {
            secondary.style.setProperty("width", parseInt(secondary.offsetWidth) + "px", "important");
            setTimeout(() => {
                secondary.style.setProperty("width", "0")
            }, 0)
        }
    }
    else {
        let max = 0
        let maxi = 0
        let containers = secondary.children
        for (let i = 0, len = containers.length; i < len; i++) {
            if (max < containers[i].offsetWidth) {
                maxi = i;
                max = containers[i].offsetWidth
            }
        }
        let secondToMax = 0
        for (let i = 0, len = containers.length; i < len; i++) {
            if (secondToMax < containers[i].offsetWidth && i !== maxi) {
                secondToMax = containers[i].offsetWidth
            }
        }
        if (container.offsetWidth !== max) {
            return;
        }
        secondToMax += 42;
        if (secondary.style.width === "auto") {
            secondary.style.animation = "max-width-animate 250ms  cubic-bezier(0, 0, 0.88, 0.15)";
        }
        else {
            secondary.style.transition = "width 250ms cubic-bezier(0, 0, 0.88, 0.15)";
        }
        secondary.style.setProperty("width", secondary.offsetWidth + "px", "important");
        if (secondary.scrollHeight > secondary.clientHeight) {
            secondToMax += 14
        }
        if (document.querySelector('#secondary:has([visibility="ENGAGEMENT_PANEL_VISIBILITY_EXPANDED"])') === null) {
            setTimeout(() => {
                secondary.style.setProperty("width", secondToMax + "px", "important");
                setTimeout(() => {
                    secondary.style.setProperty("width", "auto", "important");
                }, 250);
            }, 0)
        }


    }
}

async function removeTimestamp(timeAttribute, animation){
    let timestampsContainer = document.querySelector(`.timestamps-container:has([time='${timeAttribute}'])`)
    if (animation !== undefined) {
        timestampsContainer.style.animation = animation
    }
    else {
        timestampsContainer.style.animation = "scale-to-0-remove-timestamp 200ms ease-in-out forwards"
        handleWidthRemoveTimestamp(timestampsContainer)
        await new Promise(r => setTimeout(r, 200));
    }
    document.querySelectorAll(`.timestamps-container:not(.timestamps-container-chapter) [time="${timeAttribute}"]`).forEach((e)=>{e.remove()})
    document.querySelectorAll(`.__youtube-timestamps__stamp:not(.__youtube-timestamps__stamp__chapter)[time="${timeAttribute}"]`).forEach((e)=>{e.remove()})
    document.querySelectorAll(".timestamps-container:not(.timestamps-container-chapter):not(:has([time]))").forEach((e)=>{e.remove()})
    Qs = Qs.filter(function(item) {
        return item !== parseFloat(timeAttribute)
    })
    adjustInputsValue()
    saveTimestampsData()
    addFirstTimestampObserver()
}

let howHideTimestampsCoolDown = false
let showHideTimestampsTimeOut


function showHideTimestamps() {
    if (howHideTimestampsCoolDown) {
        return
    }
    howHideTimestampsCoolDown = true
    clearTimeout(showHideTimestampsTimeOut);
    showHideTimestampsTimeOut = setTimeout(() => {
        howHideTimestampsCoolDown = false
    }, 200);
    if (showTimestamps) {
        secondary.style.setProperty("width",  "auto", "important");
        showTimestamps = false
        chrome.storage.local.set({"showTimestamps": showTimestamps});
        secondary.style.animation = "";
        root.style.setProperty('--timestamps', '0')
        setTimeout(() => {
            root.style.setProperty('--after-fade-out', '0')
        }, 200)
        if (canCloseSecondary()) {
            secondary.style.setProperty("width", parseInt(secondary.offsetWidth - parseInt(window.getComputedStyle(document.body).getPropertyValue('font-size'))) + "px", "important");
            setTimeout(() => {
                secondary.style.setProperty("width", "0")
            }, 0)
        }
    }
    else {
        if (canCloseSecondary()) {
            secondary.style.setProperty("width", "auto", "important");
        }
        showTimestamps = true
        chrome.storage.local.set({"showTimestamps": showTimestamps});
        root.style.setProperty('--timestamps', '1')
        if (canCloseSecondary()) {
            secondary.style.animation = "max-width-animate 250ms  cubic-bezier(0, 0, 0.88, 0.15)";
        }
        setTimeoutDispatchEventInput()
       root.style.setProperty('--after-fade-out', '1')
   }
    tinyMDE.fireSelection();
    document.querySelector(".TinyMDE").dispatchEvent(new Event("input"));
}
function waitForElement(selector) {
    return new Promise(resolve => {
        if (document.querySelector(selector)) {
            return resolve(document.querySelector(selector));
        }
        const observer = new MutationObserver(mutations => {
            if (document.querySelector(selector)) {
                observer.disconnect();
                resolve(document.querySelector(selector));
            }
        });
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    });
}
function getOrCreateBar() {
    let bar = document.querySelector('.__youtube-timestamps__bar')
    if (!bar) {
        let container = document.querySelector('#movie_player .ytp-timed-markers-container')
        if (!container) {
            container = document.querySelector('#movie_player .ytp-progress-list')
        }
        if (!container) {
            return null
        }
        bar = document.createElement('div')
        bar.classList.add('__youtube-timestamps__bar')
        container.prepend(bar)
    }
    return bar
}

function dispatchEventInputs() {
    document.querySelectorAll("input[time]").forEach(function (inputEl, index) {
            inputEl.dispatchEvent(new Event("input"));
        }
    )
}
function setTimeoutDispatchEventInput() {
    setTimeout(() => {
        dispatchEventInputs()
    }, 10);
}

function adjustInputsValue(){
    document.querySelectorAll("input[time]").forEach(
        function (inputEl, index) {
            if (!isNaN(inputEl.value) || inputEl.value===''){
                if (inputEl.value !== String(index + 1)) {
                    inputEl.value = index + 1;
                    inputEl.dispatchEvent(new Event("input"));
                }
            }
        }
    )
}



async function change_rate_indicator() {
    if (video === undefined) {return}
    if (document.querySelector('.ytp-speedmaster-user-edu:not([style*="display: none"])') !== null) {return;}
    rate_indicator.textContent = String(video.playbackRate) + "X"
    rate_indicator.classList.add("show")
    rate_indicator.classList.remove("fade")
    clearTimeout(timeout);
    timeout = setTimeout(() => {
        rate_indicator.classList.remove("show")
        rate_indicator.classList.add("fade")
    }, 500);
}
function isInInput(e) { return e.target.nodeName === "INPUT" || e.target.nodeName === "TEXTAREA" || e.target.isContentEditable }
async function logKey(e) {
    if (e.code === 'KeyG' && e.shiftKey && !isInInput(e)) {
        toggleExtensionDisabled(e)
    }
    if (extensionDisabled) {return}
    if (e.code === 'Slash' && !e.shiftKey) {e.preventDefault(); e.stopPropagation();}
    if (!video) {return}
    if (e.code === 'KeyQ' && e.shiftKey && e.ctrlKey) {
        toggleFocusEditor(e)
        return
    }
    if (isInInput(e)) { return; }
    if (e.repeat) {return}
    if (e.which >= '1'.charCodeAt(0) && e.which <= '9'.charCodeAt(0)) {
        handleNumbers(e)
    }
    if (video.readyState !== 4 && e.code !== 'KeyT') {return}
    if ((e.code === 'Semicolon' || e.code === 'KeyA') && !e.shiftKey) {
        if (video.playbackRate === 1) {
            video.currentTime -= 5
        }
        else {
            video.playbackRate = 1
        }
    }
    else if (e.code === 'Slash' && e.shiftKey && !e.ctrlKey){
        addShortcutsImages()
    }
    else if (e.code === 'KeyS' && !e.ctrlKey) {
        if (e.shiftKey) {
            video.currentTime -= 30
        }
        else {
            video.currentTime -= 10
        }
    }
    else if (e.code === 'KeyW') {
        if (e.shiftKey) {
            video.currentTime += 30
        }
        else {
            video.currentTime += 5
        }
    }
    else if (e.code === 'BracketLeft' && e.shiftKey) {
        showHideTimestamps()
    }
    else if ((e.code === 'KeyE' || e.code === 'BracketLeft') && e.ctrlKey) {
        e.preventDefault()
        e.stopPropagation()
        let lastH1 = document.querySelector(".timestamps-container:nth-last-child(2) h1")
        if (!lastH1) return
        if (!lastH1.parentElement.classList.contains("timestamps-container-chapter")) {removeTimestamp(lastH1.getAttribute("time"))}
        else{
            removeContinuousTimestamp(document.querySelector(".timestamps-container:nth-last-child(2) h1[startTime]").getAttribute("startTime"))
        }
    }
    else if ((e.code === 'KeyE' || e.code === 'BracketLeft') && !e.shiftKey) {
        let lastH1 = document.querySelector(".timestamps-container:nth-last-child(2) h1")
        if (!lastH1) return
        if (!lastH1.parentElement.classList.contains("timestamps-container-chapter")) {document.querySelector(".timestamps-container:nth-last-child(2) h1").click()}
        else{document.querySelector(".timestamps-container:nth-last-child(2) h1[startTime]").click()}
    }
    else if ((e.code === "Quote" || e.code === 'KeyD') && !e.shiftKey) {
        if (video.playbackRate >= 1.5) {
            if (video.playbackRate === 16) return
            video.playbackRate += 0.5;
        }
        else {
            video.playbackRate = 1.5
        }
    }
    else if (e.code === 'KeyQ' || e.code === 'KeyP') {
        addTimeStamp(e)
    }
    else if((e.code === 'KeyR' || e.code === 'BracketRight') && !e.ctrlKey && !e.shiftKey){
        if (Qs.includes(video.currentTime)) return
        let lastContainer = document.querySelector(".timestamps-container:nth-last-child(2)")
        if (lastContainer && lastContainer.classList.contains("timestamps-container-chapter")) return
        let numTimestampsContainer = Array.from(document.querySelectorAll(".timestamps-container")).length
        let timestampsContainerAnimation = numTimestampsContainer === 0 ? undefined : "none"
        if (numTimestampsContainer >= 1) { removeTimestamp(lastContainer.firstChild.getAttribute("time"), "none") }
        addTimeStamp(e, timestampsContainerAnimation)
    }
    else if(e.code === 'KeyD' && e.shiftKey){
        alwaysShowHeatmap = !alwaysShowHeatmap
        chrome.storage.local.set({ "alwaysShowHeatmap": alwaysShowHeatmap });
        if (alwaysShowHeatmap && !document.querySelector("#movie_player").classList.contains("ytp-autohide")){
            document.querySelector("#canvas-div").style.opacity = "1"
            heatMapChart.update();
            updateHeatmap = true
        }
        else{
            document.querySelector("#canvas-div").style.opacity = "0"
            updateHeatmap = false
        }
    }
    else if (e.code === 'KeyR' && e.shiftKey) {
        counter = new Array(Math.ceil(video.duration / secondsSplit)+1).fill(0);
        heatMapChart.data.datasets[0].data = counter
        heatMapChart.update();
        updateBorderColors()
        saveHeatmapData()
    }
    else if (e.code === 'KeyA' && e.shiftKey) {
        video.currentTime = counter.indexOf(Math.max(...counter))*secondsSplit
    }
    else if (e.code === 'KeyH' && e.shiftKey) {
        let hidden = document.querySelector(".tinymde-container").style.display === 'none'
        if (hidden) {
            document.querySelector(".tinymde-container").style.display = ""
            document.querySelector(".tinymde-container").style.opacity = "1"
            document.querySelector(".tinymde-container").style.animation = "scale-to-1 200ms ease-in-out forwards"
        }
        else {
            document.querySelector(".tinymde-container").style.opacity = "0"
            document.querySelector(".tinymde-container").style.animation = "scale-to-0 200ms ease-in-out forwards"
            setTimeout(() => {
                document.querySelector(".tinymde-container").style.display = "none"
            }, 200);
        }
        chrome.storage.local.set({isHideMDE: !hidden})
    }
    else if (e.code === 'KeyF' && e.shiftKey && !e.ctrlKey) {
        e.preventDefault()
        if (document.querySelector('[target-id="engagement-panel-searchable-transcript"][visibility="ENGAGEMENT_PANEL_VISIBILITY_EXPANDED"] #visibility-button button')) {
            document.querySelector('[target-id="engagement-panel-searchable-transcript"] #visibility-button button').click()
        }
        else if (document.querySelector(".ytd-video-description-transcript-section-renderer button")){
            document.querySelector(".ytd-video-description-transcript-section-renderer button").click()
        }
    }
    else if (e.code === 'KeyT') {
        addContinuousTimeStampBar(e, e.shiftKey)
    }
    else if (document.querySelector(".ytp-chapters-container").childNodes.length === 1 && e.ctrlKey && (e.code === 'ArrowLeft' || e.code === 'ArrowRight')) {
        let QsPlusOffsetsArr = Qs.slice()
        let offsetsArrToSeconds = offsetsArr.flat(Infinity).map(num=>{return num * video.duration / 100})
        if (offsetsArr.length!==0){QsPlusOffsetsArr.push(...offsetsArrToSeconds.flat(Infinity))}
        QsPlusOffsetsArr.sort((a, b) => a-b)
        if (e.code === 'ArrowLeft') {
            QsPlusOffsetsArr.reverse()
            for (let time of QsPlusOffsetsArr) {
                if (time < video.currentTime - 5) {
                    video.currentTime = time
                    break
                }
            }
        }
        else if (e.code === 'ArrowRight') {
            for (let time of QsPlusOffsetsArr) {
                if (time > video.currentTime) {
                    video.currentTime = time
                    break
                }
            }
        }
    }


}
window.addEventListener('click', event => {
    if (event.target.matches('video')) {
        event.stopPropagation();
        if (event.target.paused){
            event.target.play()
        }
        else{
            event.target.pause()
        }
    }
}, true);

function updateVideoPlayer() {
    video = document.querySelector("video")
    if (video.readyState !== 4) { video.onloadedmetadata = onVideoLoad }
    else {
        onVideoLoad()
    }
    if (!firstLoad) {
        return;
    }
    listenForRateChange()
    addTotalTimeSpan();
    document.querySelector("video").addEventListener('pause', function (e) {
        document.querySelector("[aria-keyshortcuts='k'] > svg path").style.d = 'path("M 12,26 18.5,22 18.5,14 12,10 z M 18.5,22 25,18 25,18 18.5,14 z")'
    });
    document.querySelector("video").addEventListener('play', function (e) {
        document.querySelector("[aria-keyshortcuts='k'] > svg path").style.d = 'path("M 12,26 16,26 16,10 12,10 z M 21,26 25,26 25,10 21,10 z")'
    });

    console.log(
        `%cVimTube Extension Activated`,
        `background: linear-gradient(90deg, rgba(52,84,244,1) 0%, rgba(50,129,244,1) 25%, rgba(85,166,246,1) 50%, rgba(43,189,251,1) 75%, rgba(52,84,244,1) 100%);color: gold;font-weight: 900`
    );
}

function pageUpdateListener(){
    document.querySelectorAll("[time], .timestamps-container, .__youtube-heatmap__bar, .__youtube-timestamps__stamp__chapter, .tinymde-container, .zero-space-wrapper").forEach((e)=>{e.remove()})
    reset()
    if (watchPage()){
        updateVideoPlayer();
        turnOnCaptions()
        firstLoad = false
    }
}





window.addEventListener('yt-page-data-updated', pageUpdateListener);
replaceVimTubeLogo()
loadLocalStorage()

document.body.onkeydown = (e => {
    if (e.target.classList.contains("TinyMDE")) {
        e.stopPropagation();
    }
})
